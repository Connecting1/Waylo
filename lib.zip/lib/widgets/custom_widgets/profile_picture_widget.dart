// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';
// import 'package:waylo_flutter/services/api_service.dart'; // ✅ ApiService 추가
//
// class ProfilePictureWidget extends StatefulWidget {
//   final String userId;
//   final double x;
//   final double y;
//   final double width;
//   final double height;
//   final Function(double, double) onPositionChanged;
//   final Function(File?) onImageChanged;
//
//   const ProfilePictureWidget({
//     Key? key,
//     required this.userId,
//     required this.x,
//     required this.y,
//     required this.width,
//     required this.height,
//     required this.onPositionChanged,
//     required this.onImageChanged,
//   }) : super(key: key);
//
//   @override
//   _ProfilePictureWidgetState createState() => _ProfilePictureWidgetState();
// }
//
// class _ProfilePictureWidgetState extends State<ProfilePictureWidget> {
//   File? _imageFile;
//   String? _imageUrl;
//   final ImagePicker _picker = ImagePicker();
//   double _scale = 1.0; // 확대 배율
//   double _previousScale = 1.0;
//
//   @override
//   void initState() {
//     super.initState();
//     _loadProfileImage();
//   }
//
//   Future<void> _loadProfileImage() async {
//     String? imageUrl = await ApiService.fetchUserProfileImage();
//     if (imageUrl != null) {
//       setState(() {
//         _imageUrl = imageUrl;
//       });
//     }
//   }
//
//   Future<void> _uploadProfileImage(File imageFile) async {
//     String? newImageUrl = await ApiService.uploadProfileImage(
//       userId: widget.userId,
//       imageFile: imageFile,
//     );
//
//     if (newImageUrl != null) {
//       setState(() {
//         _imageUrl = newImageUrl;
//       });
//     }
//   }
//
//   Future<void> _pickImage() async {
//     final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
//     if (pickedFile != null) {
//       File imageFile = File(pickedFile.path);
//       setState(() {
//         _imageFile = imageFile;
//       });
//       widget.onImageChanged(imageFile);
//       await _uploadProfileImage(imageFile);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Positioned(
//       left: widget.x,
//       top: widget.y,
//       child: GestureDetector(
//         onTap: _pickImage,
//         onScaleStart: (details) {
//           _previousScale = _scale;
//         },
//         onScaleUpdate: (details) {
//           setState(() {
//             _scale = _previousScale * details.scale;
//             if (_scale < 1.0) _scale = 1.0; // 최소 크기 제한
//             if (_scale > 3.0) _scale = 3.0; // 최대 확대 배율 제한
//           });
//         },
//         child: Draggable(
//           feedback: Transform.scale(scale: _scale, child: _buildProfileImage()),
//           childWhenDragging: Container(),
//           onDragEnd: (details) {
//             widget.onPositionChanged(details.offset.dx, details.offset.dy);
//           },
//           child: Transform.scale(scale: _scale, child: _buildProfileImage()),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildProfileImage() {
//     return ClipOval(
//       child: _imageFile != null
//           ? Image.file(_imageFile!, width: widget.width, height: widget.height, fit: BoxFit.cover)
//           : _imageUrl != null
//           ? Image.network(_imageUrl!, width: widget.width, height: widget.height, fit: BoxFit.cover)
//           : Container(
//         width: widget.width,
//         height: widget.height,
//         decoration: BoxDecoration(
//           color: Colors.grey[300],
//           shape: BoxShape.circle,
//         ),
//         child: Icon(Icons.person, size: widget.width / 2, color: Colors.white),
//       ),
//     );
//   }
// }
