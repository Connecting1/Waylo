// import 'dart:convert';
// import 'dart:io';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:path/path.dart';
//
// class ApiService {
//   static const String baseUrl = "http://192.168.0.6:8000";
//
//   // ✅ 회원가입 API
//   static Future<Map<String, dynamic>> createUser({
//     required String email,
//     required String? password,
//     required String gender,
//     required String username,
//     required String phoneNumber,
//     required String provider,
//     String? profileImage,
//   }) async {
//     print("🔵 API 요청 시작");
//
//     final url = Uri.parse("$baseUrl/users/create/");
//
//     try {
//       final Map<String, dynamic> requestBody = {
//         "email": email,
//         "password": password,
//         "gender": gender.toLowerCase(),
//         "username": username,
//         "phone_number": phoneNumber,
//         "provider": provider,
//       };
//
//       if (profileImage != null) {
//         requestBody["profile_image"] = profileImage;
//       }
//
//       final response = await http.post(
//         url,
//         headers: {"Content-Type": "application/json"},
//         body: jsonEncode(requestBody),
//       );
//
//       if (response.statusCode == 201) {
//         return jsonDecode(response.body);
//       } else {
//         return {"error": response.body};
//       }
//     } catch (e) {
//       return {"error": "Network error or invalid response"};
//     }
//   }
//
//   // 로그인 API
//   static Future<Map<String, dynamic>> loginUser(String email, String password) async {
//     final url = Uri.parse("$baseUrl/users/login/");
//     try {
//       final response = await http.post(
//         url,
//         headers: {"Content-Type": "application/json"},
//         body: jsonEncode({"email": email, "password": password}),
//       );
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//
//         SharedPreferences prefs = await SharedPreferences.getInstance();
//         await prefs.setString("loggedInEmail", email); // ✅ 로그인한 이메일 저장
//
//         return data;
//
//       } else {
//         return {"error": "로그인 실패, 이메일 또는 비밀번호를 확인하세요."};
//       }
//     } catch (e) {
//       return {"error": "Network error or invalid response"};
//     }
//   }
//
//   static Future<String?> getLoggedInEmail() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     return prefs.getString("loggedInEmail");
//   }
//
//
//   static Future<Map<String, dynamic>> fetchUserInfo() async {
//     // SharedPreferences에서 user_id 가져오기
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String? userId = prefs.getString("user_id");
//
//     if (userId == null) {
//       return {"error": "No User Logged In"}; // 로그인된 사용자 없을 경우
//     }
//
//     // ✅ GET 요청: 모든 유저 데이터 가져오기
//     final url = Uri.parse("$baseUrl/api/users/$userId/");
//
//     try {
//       final response = await http.get(
//         url,
//         headers: {"Content-Type": "application/json"},
//       );
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         return {
//           "username": data['username'] ?? "Unknown User",
//           "profile_image": data['profile_image'],
//           "email": data['email'],
//           "gender": data['gender'],
//           "phone_number": data['phone_number'],
//           "created_at": data['created_at'],
//           "account_visibility": data['account_visibility'],
//         };
//       } else {
//         return {"error": "Server Error"};
//       }
//     } catch (e) {
//       return {"error": "Request Failed"};
//     }
//   }
//
//
//
//   static Future<Map<String, dynamic>> fetchAlbumInfo() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String? userId = prefs.getString("user_id");
//
//     if (userId == null) {
//       return {"error": "No User Logged In"};
//     }
//
//     final url = Uri.parse("$baseUrl/api/albums/$userId/");
//
//     try {
//       final response = await http.get(
//         url,
//         headers: {"Content-Type": "application/json"},
//       );
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         return {
//           "user_id": data['user_id'],
//           "background_color": data['background_color'] ?? "#FFFFFF",
//           "background_pattern": data['background_pattern'] ?? "none",
//           "created_at": data['created_at'],
//         };
//       } else {
//         return {"error": "Server Error"};
//       }
//     } catch (e) {
//       return {"error": "Request Failed"};
//     }
//   }
//
//
//
//
//   static Future<String?> fetchUserProfileImage() async {
//     // SharedPreferences에서 user_id 가져오기
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String? userId = prefs.getString("user_id");
//
//     if (userId == null) {
//       return null; // 로그인된 사용자 없음
//     }
//
//     final url = Uri.parse("$baseUrl/get-user-info/");
//
//     try {
//       final response = await http.post(
//         url,
//         headers: {"Content-Type": "application/json"},
//         body: jsonEncode({"user_id": userId}), // user_id 전송
//       );
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         String? profileImagePath = data['profile_image'];
//
//         if (profileImagePath != null) {
//           return "$baseUrl$profileImagePath"; // ✅ 서버 주소 붙여서 반환
//         } else {
//           return null; // 프로필 이미지 없음
//         }
//       } else {
//         return null; // 서버 오류
//       }
//     } catch (e) {
//       return null; // 네트워크 오류
//     }
//   }
//
//
//
//
//
//   static Future<String?> uploadProfileImage({required String userId, required File imageFile}) async {
//     final url = Uri.parse("$baseUrl/users/upload-profile-image/");
//
//     try {
//       var request = http.MultipartRequest("POST", url);
//       request.fields["user_id"] = userId; // UUID 전송
//       request.files.add(
//         await http.MultipartFile.fromPath(
//           "file", imageFile.path,
//           filename: basename(imageFile.path), // 파일명 유지
//         ),
//       );
//
//       var streamedResponse = await request.send();
//       var response = await http.Response.fromStream(streamedResponse);
//
//       if (response.statusCode == 200) {
//         final Map<String, dynamic> responseData = json.decode(response.body);
//         return responseData["profile_image"]; // Django에서 반환된 이미지 URL
//       } else {
//         print("❌ 프로필 이미지 업로드 실패: ${response.body}");
//         return null;
//       }
//     } catch (e) {
//       print("❌ 예외 발생: $e");
//       return null;
//     }
//   }
//
//   static Future<Map<String, dynamic>> updateUserInfo({
//     required String userId,
//     String? username,
//     String? email,
//     String? gender,
//     String? phoneNumber,
//     String? accountVisibility,
//     File? profileImage,
//   }) async {
//     final url = Uri.parse("$baseUrl/api/users/$userId/update/");
//     var request = http.MultipartRequest("PATCH", url);
//
//     // JSON 데이터 추가
//     request.fields["username"] = username ?? "";
//     request.fields["email"] = email ?? "";
//     request.fields["gender"] = gender ?? "";
//     request.fields["phone_number"] = phoneNumber ?? "";
//     request.fields["account_visibility"] = accountVisibility ?? "";
//
//     // ✅ 프로필 이미지가 있을 경우 추가
//     if (profileImage != null) {
//       request.files.add(
//         await http.MultipartFile.fromPath(
//           "file",
//           profileImage.path,
//           filename: basename(profileImage.path),
//         ),
//       );
//     }
//
//     try {
//       var streamedResponse = await request.send();
//       var response = await http.Response.fromStream(streamedResponse);
//
//       if (response.statusCode == 200) {
//         return jsonDecode(response.body); // ✅ 성공 시 응답 데이터 반환
//       } else {
//         return {"error": "Server Error"};
//       }
//     } catch (e) {
//       return {"error": "Request Failed"};
//     }
//   }
//
// }





















import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart';

class ApiService {
  static const String baseUrl = "http://192.168.0.6:8000";

  // ✅ 공통: SharedPreferences에서 user_id 가져오기
  static Future<String?> _getUserId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString("user_id");
  }

  // ✅ 공통: HTTP 요청 핸들러 (GET, POST, PATCH 등)
  static Future<Map<String, dynamic>> _sendRequest({
    required String endpoint,
    String method = "GET",
    Map<String, dynamic>? body,
    File? file,
  }) async {
    final url = Uri.parse("$baseUrl$endpoint");

    try {
      http.Response response;

      if (method == "GET") {
        response = await http.get(url, headers: {"Content-Type": "application/json"});
      } else if (method == "POST") {
        response = await http.post(
          url,
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(body),
        );
      } else if (method == "PATCH") {
        var request = http.MultipartRequest("PATCH", url);
        if (body != null) {
          body.forEach((key, value) => request.fields[key] = value.toString());
        }
        if (file != null) {
          request.files.add(
            await http.MultipartFile.fromPath("file", file.path, filename: basename(file.path)),
          );
        }
        var streamedResponse = await request.send();
        response = await http.Response.fromStream(streamedResponse);
      } else {
        return {"error": "Invalid HTTP method"};
      }

      if (response.statusCode == 200 || response.statusCode == 201) {
        return jsonDecode(response.body);
      } else {
        return {"error": response.body};
      }
    } catch (e) {
      return {"error": "Request Failed"};
    }
  }

  // ✅ 회원가입 API
  static Future<Map<String, dynamic>> createUser({
    required String email,
    required String? password,
    required String gender,
    required String username,
    required String phoneNumber,
    required String provider,
    String? profileImage,
  }) async {
    return await _sendRequest(
      endpoint: "/users/create/",
      method: "POST",
      body: {
        "email": email,
        "password": password,
        "gender": gender.toLowerCase(),
        "username": username,
        "phone_number": phoneNumber,
        "provider": provider,
        "profile_image": profileImage,
      },
    );
  }

  // ✅ 로그인 API
  static Future<Map<String, dynamic>> loginUser(String email, String password) async {
    return await _sendRequest(
      endpoint: "/users/login/",
      method: "POST",
      body: {"email": email, "password": password},
    );
  }

  // ✅ 사용자 정보 가져오기 (GET)
  static Future<Map<String, dynamic>> fetchUserInfo() async {
    String? userId = await _getUserId();
    if (userId == null) return {"error": "No User Logged In"};
    return await _sendRequest(endpoint: "/api/users/$userId/");
  }

  // ✅ 앨범 정보 가져오기 (GET)
  static Future<Map<String, dynamic>> fetchAlbumInfo() async {
    String? userId = await _getUserId();
    if (userId == null) return {"error": "No User Logged In"};
    return await _sendRequest(endpoint: "/api/albums/$userId/");
  }

  // ✅ 프로필 이미지 업로드 (POST)
  // static Future<String?> uploadProfileImage({required String userId, required File imageFile}) async {
  //   Map<String, dynamic> response = await _sendRequest(
  //     endpoint: "/users/upload-profile-image/",
  //     method: "POST",
  //     file: imageFile,
  //     body: {"user_id": userId},
  //   );
  //   return response["profile_image"];
  // }

  // ✅ 유저 정보 수정 (PATCH)
  static Future<Map<String, dynamic>> updateUserInfo({
    required String userId,
    String? username,
    String? email,
    String? gender,
    String? phoneNumber,
    String? accountVisibility,
    File? profileImage,
  }) async {
    return await _sendRequest(
      endpoint: "/api/users/$userId/update/",
      method: "PATCH",
      body: {
        "username": username,
        "email": email,
        "gender": gender,
        "phone_number": phoneNumber,
        "account_visibility": accountVisibility,
      },
      file: profileImage,
    );
  }
}
