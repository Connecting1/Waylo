import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart';

class ApiService {
  static const String baseUrl = "http://192.168.45.193:8000";

  // ✅ 회원가입 API
  static Future<Map<String, dynamic>> createUser({
    required String email,
    required String? password,
    required String gender,
    required String username,
    required String phoneNumber,
    required String provider,
    String? profileImage,
  }) async {
    print("🔵 API 요청 시작");

    final url = Uri.parse("$baseUrl/users/create/");

    try {
      final Map<String, dynamic> requestBody = {
        "email": email,
        "password": password,
        "gender": gender.toLowerCase(),
        "username": username,
        "phone_number": phoneNumber,
        "provider": provider,
      };

      if (profileImage != null) {
        requestBody["profile_image"] = profileImage;
      }

      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 201) {
        return jsonDecode(response.body);
      } else {
        return {"error": response.body};
      }
    } catch (e) {
      return {"error": "Network error or invalid response"};
    }
  }

  // 로그인 API
  static Future<Map<String, dynamic>> loginUser(String email, String password) async {
    final url = Uri.parse("$baseUrl/users/login/");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"email": email, "password": password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString("loggedInEmail", email); // ✅ 로그인한 이메일 저장

        return data;

      } else {
        return {"error": "로그인 실패, 이메일 또는 비밀번호를 확인하세요."};
      }
    } catch (e) {
      return {"error": "Network error or invalid response"};
    }
  }

  static Future<String?> getLoggedInEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString("loggedInEmail");
  }


  static Future<String> fetchUserName() async {
    // SharedPreferences에서 user_id 가져오기
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString("user_id");

    if (userId == null) {
      return "No User Logged In"; // 로그인된 사용자 없을 경우
    }

    final url = Uri.parse("$baseUrl/get-user-info/");

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"user_id": userId}), // user_id를 사용하여 요청
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['username'] ?? "Unknown User";
      } else {
        return "Server Error";
      }
    } catch (e) {
      return "Request Failed";
    }
  }

  static Future<String?> fetchUserProfileImage() async {
    // SharedPreferences에서 user_id 가져오기
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString("user_id");

    if (userId == null) {
      return null; // 로그인된 사용자 없음
    }

    final url = Uri.parse("$baseUrl/get-user-info/");

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"user_id": userId}), // user_id 전송
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String? profileImagePath = data['profile_image'];

        if (profileImagePath != null) {
          return "$baseUrl$profileImagePath"; // ✅ 서버 주소 붙여서 반환
        } else {
          return null; // 프로필 이미지 없음
        }
      } else {
        return null; // 서버 오류
      }
    } catch (e) {
      return null; // 네트워크 오류
    }
  }





  static Future<String?> uploadProfileImage({required String userId, required File imageFile}) async {
    final url = Uri.parse("$baseUrl/users/upload-profile-image/");

    try {
      var request = http.MultipartRequest("POST", url);
      request.fields["user_id"] = userId; // UUID 전송
      request.files.add(
        await http.MultipartFile.fromPath(
          "file", imageFile.path,
          filename: basename(imageFile.path), // 파일명 유지
        ),
      );

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return responseData["profile_image"]; // Django에서 반환된 이미지 URL
      } else {
        print("❌ 프로필 이미지 업로드 실패: ${response.body}");
        return null;
      }
    } catch (e) {
      print("❌ 예외 발생: $e");
      return null;
    }
  }
}
