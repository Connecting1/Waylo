import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:waylo_flutter/services/api_service.dart';
import 'package:waylo_flutter/screens/profile/profile_screen.dart';

class MyMapScreenPage extends StatefulWidget {
  const MyMapScreenPage({super.key});

  @override
  _MapScreenPageState createState() => _MapScreenPageState();
}

class _MapScreenPageState extends State<MyMapScreenPage> {
  String userName = "Loading...";
  late MapboxMap mapboxMap;
  late String accessToken;
  PointAnnotationManager? pointAnnotationManager;

  @override
  void initState() {
    super.initState();
    accessToken = const String.fromEnvironment("ACCESS_TOKEN");
    MapboxOptions.setAccessToken(accessToken);
    loadUserName();
  }

  Future<void> loadUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString("user_id");

    // user_id 값이 정상적으로 읽혔는지 확인
    print("✅ 보내는 user_id: $userId");  // user_id 확인용 로그 추가

    if (userId == null) {
      setState(() {
        userName = "No User Logged In";
      });
      return;
    }

    String fetchedUserName = await ApiService.fetchUserName();  // API 호출
    setState(() {
      userName = fetchedUserName;
    });
  }

  // Future<void> loadUserName() async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   String? userId = prefs.getString("user_id");
  //
  //   if (userId == null) {
  //     setState(() {
  //       userName = "No User Logged In";
  //     });
  //     return;
  //   }
  //
  //   // `userId`로 최신 username을 가져오는 API 호출
  //   String fetchedUserName = await ApiService.fetchUserName(userId);  // API 수정 필요
  //   setState(() {
  //     userName = fetchedUserName;
  //   });
  // }


  /// **🌍 JSON에서 국가 데이터 불러와 마커 추가**
  Future<void> _addCountryMarkers() async {
    pointAnnotationManager =
    await mapboxMap.annotations.createPointAnnotationManager();

    // 🌍 `assets/mapbox/countries.json` 파일에서 데이터 로드
    String data = await rootBundle.loadString('assets/mapbox/countries.json');
    Map<String, dynamic> geoJson = jsonDecode(data);

    // 모든 나라에 마커 추가
    for (var feature in geoJson["features"]) {
      var coordinates = feature["geometry"]["coordinates"];
      String countryName = feature["properties"]["name"];
      String iconPath = feature["properties"]["icon"];

      Uint8List? imageData;

      // ✅ 네트워크 이미지인지 확인 후 다운로드
      if (iconPath.startsWith("http")) {
        imageData = await _downloadImage(iconPath); // 🔥 네트워크 이미지 다운로드
      } else {
        final ByteData bytes = await rootBundle.load(iconPath);
        imageData = bytes.buffer.asUint8List();
      }

      if (imageData == null) continue;

      PointAnnotationOptions pointAnnotationOptions = PointAnnotationOptions(
        geometry: Point(coordinates: Position(coordinates[0], coordinates[1])),
        image: imageData, // 🖼️ 아이콘 설정
        iconSize: 0.5, // 아이콘 크기
      );

      // 마커(아이콘) 추가
      await pointAnnotationManager?.create(pointAnnotationOptions);
      debugPrint("✅ ${countryName} 마커 추가됨 (${coordinates[1]}, ${coordinates[0]})");
    }
  }

  /// **🌍 네트워크에서 이미지 다운로드 후 Uint8List 변환**
  Future<Uint8List?> _downloadImage(String url) async {
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        return response.bodyBytes;
      } else {
        debugPrint("❌ 이미지 다운로드 실패: $url");
        return null;
      }
    } catch (e) {
      debugPrint("❌ 이미지 다운로드 중 오류 발생: $e");
      return null;
    }
  }

  /// **🗺️ Map이 생성되었을 때 실행되는 콜백**
  Future<void> _onMapCreated(MapboxMap mapboxMap) async {
    this.mapboxMap = mapboxMap;
    await _addCountryMarkers(); // 모든 나라의 마커 추가
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: () {
            //프로필 페이지로 이동
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const ProfileScreenPage()),
            );
          },
          child: Text(userName),
        ),
      ),
      body: MapWidget(
        cameraOptions: CameraOptions(
          center: Point(coordinates: Position(0, 20)), // 세계 중심으로 설정
          zoom: 2,
        ),
        onMapCreated: _onMapCreated, // 지도 생성 시 실행
      ),
    );
  }
}
