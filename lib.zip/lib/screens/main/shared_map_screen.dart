import 'package:flutter/material.dart';

class SharedMapScreenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: Text('공유맵 페이지'),
        ),
      ),
    );
  }
}