import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart'; // image_picker 패키지 추가
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../../services/api_service.dart';
import 'package:image_cropper_platform_interface/image_cropper_platform_interface.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import '../../styles/app_styles.dart';

class AlbumScreenPage extends StatefulWidget {
  @override
  _AlbumScreenPageState createState() => _AlbumScreenPageState();
}

class _AlbumScreenPageState extends State<AlbumScreenPage> {
  Color _canvasColor = Colors.white; // 기본 캔버스 색상
  String _canvasPattern = "none"; // 기본 배경 패턴 (없음)
  final ImagePicker _picker = ImagePicker();
  static const platform = MethodChannel('gallery_channel');
  String? _profileImageUrl;
  List<Widget> _canvasWidgets = [];
  bool _isEditingProfile = false;

  @override
  void initState() {
    super.initState();
    _loadCanvasSettings(); // 저장된 배경 설정 불러오기
  }

  Future<void> _loadCanvasSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _canvasColor = Color(prefs.getInt('canvas_color') ?? Colors.white.value);
      _canvasPattern = prefs.getString('canvas_pattern') ?? "none";
    });
  }

  Future<void> _saveCanvasSettings(Color color, String pattern) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('canvas_color', color.value);
    await prefs.setString('canvas_pattern', pattern);
  }

  Future<String?> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("user_id");  // SharedPreferences에서 저장된 user_id 가져오기
  }

  Future<void> _saveProfilePicture(File tempFile) async {
    // 앱의 로컬 저장소 경로 가져오기
    final Directory appDir = await getApplicationDocumentsDirectory();
    final Directory profilePicDir = Directory('${appDir.path}/uploads/profile_pics');

    // `uploads/profile_pics` 폴더가 없으면 생성
    if (!profilePicDir.existsSync()) {
      profilePicDir.createSync(recursive: true);
    }

    // 새 파일 경로 설정
    final String fileName = "profile_picture.png"; // 파일명 고정
    final File newImage = File('${profilePicDir.path}/$fileName');

    // 기존 파일 삭제 후 새 파일 저장
    if (newImage.existsSync()) {
      newImage.deleteSync();
    }

    await tempFile.copy(newImage.path);
  }


  Future<void> _pickAndUploadImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile == null) {
      print("❌ 사진을 선택하지 않았음");
      return;
    }

    File imageFile = File(pickedFile.path);
    print("✅ 선택한 사진 경로: ${imageFile.path}");

    // 1. 크롭 UI 실행하여 사용자가 조절 가능하도록 함
    final croppedFile = await _cropImage(imageFile);

    if (croppedFile == null) {
      print("❌ 크롭된 이미지가 없음");
      return;
    }

    print("✅ 크롭된 이미지 경로: ${croppedFile.path}");

    // ✅ 현재 로그인된 유저의 ID 가져오기
    String? userId = await _getUserId();  // SharedPreferences에서 유저 ID 가져오기

    if (userId == null) {
      print("❌ 사용자 ID를 가져오지 못함");
      return;
    }

    // ✅ Django API로 원형으로 크롭된 이미지 업로드
    String? imageUrl = await ApiService.uploadProfileImage(userId: userId, imageFile: croppedFile);

    if (imageUrl != null) {
      print("✅ 프로필 사진 업로드 성공: $imageUrl");
    } else {
      print("❌ 프로필 사진 업로드 실패");
    }
  }

  Future<File?> _cropImage(File imageFile) async {
    final croppedFile = await ImageCropper().cropImage(
      sourcePath: imageFile.path,
      aspectRatio: const CropAspectRatio(ratioX: 1.0, ratioY: 1.0), // 🔥 정사각형으로 자름
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: '사진 자르기',
          toolbarColor: AppColors.primary,
          toolbarWidgetColor: Colors.white,
          lockAspectRatio: true, // 🔥 정사각형 고정
          hideBottomControls: true,
          cropFrameColor: Colors.transparent, // ✅ 크롭 프레임 숨기기
          dimmedLayerColor: Colors.black.withOpacity(0.5), // ✅ 바깥 부분 어둡게 처리
          showCropGrid: false, // ✅ 그리드 숨기기
        ),
        IOSUiSettings(
          title: '사진 자르기',
          aspectRatioLockEnabled: true,
        ),
      ],
    );

    return croppedFile != null ? File(croppedFile.path) : null;
  }



  void _editProfilePicture() {
    setState(() {
      int index = _canvasWidgets.indexWhere((widget) => widget.key == ValueKey("profile_picture"));

      if (index != -1) {
        if (_isEditingProfile) {
          // ✅ 이미 편집 모드이면 원래 프로필 사진으로 복귀
          _canvasWidgets[index] = _buildProfilePicture(_profileImageUrl ?? "assets/default_profile.png");
        } else {
          // ✅ 편집 모드 활성화 (InteractiveViewer 적용)
          _canvasWidgets[index] = Stack(
            key: ValueKey("profile_picture"),
            children: [
              SizedBox.expand(
                child: InteractiveViewer(
                  maxScale: 5.0,
                  minScale: 0.5,
                  boundaryMargin: const EdgeInsets.all(double.infinity),
                  child: Align(
                    alignment: Alignment.center,
                    child: ClipOval(
                      child: Image.network(
                        _profileImageUrl ?? "assets/default_profile.png",
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Image.asset(
                            "assets/default_profile.png",
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
              // ✅ 종료 버튼 추가
              Positioned(
                top: 20,
                right: 20,
                child: FloatingActionButton(
                  mini: true,
                  backgroundColor: Colors.red,
                  onPressed: () {
                    setState(() {
                      _isEditingProfile = false;
                      _canvasWidgets[index] = _buildProfilePicture(_profileImageUrl ?? "assets/default_profile.png");
                    });
                  },
                  child: Icon(Icons.close, color: Colors.white),
                ),
              ),
            ],
          );
        }
        _isEditingProfile = !_isEditingProfile; // ✅ 상태 토글
      }
    });
  }





  void _openWidgetSelection() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.4,
          minChildSize: 0.2,
          maxChildSize: 0.9,
          builder: (context, scrollController) {
            return Container(
              padding: EdgeInsets.all(16),
              child: ListView(
                controller: scrollController,
                children: [
                  Text("Settings & Add Widget", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  ListTile(
                    leading: Icon(Icons.color_lens, color: _canvasColor),
                    title: Text("Change Canvas Background"),
                    onTap: () {
                      Navigator.pop(context);
                      _pickCanvasBackground(context);
                    },
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(Icons.person),
                    title: Text("Profile Picture"),
                    onTap: () {
                      _showProfilePictureOptions();
                    },
                  ),
                  ListTile(
                    leading: Icon(Icons.account_circle),
                    title: Text("User ID"),
                    onTap: () {},
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _pickCanvasBackground(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text("Select Canvas Background"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SingleChildScrollView(
                    child: ColorPicker(
                      pickerColor: _canvasColor,
                      onColorChanged: (Color color) {
                        setState(() => _canvasColor = color);
                        this.setState(() => _canvasColor = color);
                        _saveCanvasSettings(color, _canvasPattern);
                      },
                      showLabel: true,
                      pickerAreaHeightPercent: 0.8,
                    ),
                  ),
                  Divider(),
                  DropdownButton<String>(
                    value: _canvasPattern,
                    items: [
                      DropdownMenuItem(value: "none", child: Text("No Pattern")),
                      DropdownMenuItem(value: "pattern1", child: Text("Pattern 1")),
                      DropdownMenuItem(value: "pattern2", child: Text("Pattern 2")),
                      DropdownMenuItem(value: "pattern3", child: Text("Pattern 3")),
                      DropdownMenuItem(value: "pattern4", child: Text("Pattern 4")),
                      DropdownMenuItem(value: "pattern5", child: Text("Pattern 5")),
                      DropdownMenuItem(value: "pattern6", child: Text("Pattern 6")),
                    ],
                    onChanged: (String? pattern) {
                      if (pattern != null) {
                        setState(() {
                          _canvasPattern = pattern;
                        });
                        this.setState(() {
                          _canvasPattern = pattern;
                        });
                        _saveCanvasSettings(_canvasColor, pattern);
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text("OK"),
                )
              ],
            );
          },
        );
      },
    );
  }

  // 프로필 사진 선택 다이얼로그 추가
  void _showProfilePictureOptions() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.image),
              title: Text("Insert Profile Picture"),
              onTap: () {
                Navigator.pop(context);
                _insertProfilePicture();
              },
            ),
            ListTile(
              leading: Icon(Icons.photo_library),
              title: Text("Change Profile Picture"),
              onTap: () {
                Navigator.pop(context);
                // _changeProfilePicture();
                _pickAndUploadImage();
              },
            ),
          ],
        );
      },
    );
  }

  // 현재 프로필 사진을 보여주는 다이얼로그 추가
  void _insertProfilePicture() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString("user_id");

    if (userId == null) {
      print("❌ 사용자 ID를 찾을 수 없음");
      return;
    }

    // ✅ API 호출하여 프로필 사진 가져오기
    String? profileImageUrl = await ApiService.fetchUserProfileImage();

    if (profileImageUrl == null) {
      print("❌ 프로필 사진이 없음, 기본 이미지 사용");
      profileImageUrl = "assets/default_profile.png"; // 기본 이미지 경로
    }

    setState(() {
      _profileImageUrl = profileImageUrl;

      bool hasProfilePicture = _canvasWidgets.any((widget) => widget.key == ValueKey("profile_picture"));

      if (hasProfilePicture) {
        // 기존 프로필 사진 위치 변경
        int index = _canvasWidgets.indexWhere((widget) => widget.key == ValueKey("profile_picture"));
        if (index != -1) {
          _canvasWidgets[index] = _buildProfilePicture(_profileImageUrl!);
        }
      } else {
        // ✅ 새로운 프로필 사진 추가
        _canvasWidgets.add(_buildProfilePicture(_profileImageUrl!));
      }
    });

    print("✅ 프로필 사진 URL: $profileImageUrl");
  }



  Widget _buildProfilePicture(String imageUrl) {
    return Center(
      key: ValueKey("profile_picture"), // ✅ 중복 추가 방지용 키 설정
      child: GestureDetector(
        onLongPress: () {
          _showBottomActionBar("profile_picture");
        },
        child: ClipOval(
          child: Image.network(
            imageUrl,
            width: 80,
            height: 80,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Image.asset(
                "assets/default_profile.png",
                width: 80,
                height: 80,
                fit: BoxFit.cover,
              );
            },
          ),
        ),
      ),
    );
  }


  void _showBottomActionBar(String selectedWidgetKey) {
    if (selectedWidgetKey == "profile_picture") {
      showModalBottomSheet(
        context: context,
        backgroundColor: AppColors.primary,
        barrierColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(15)), // ✅ 둥근 모서리 추가
        ),
        builder: (BuildContext context) {
          return Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _actionButton(Icons.image, "change", Colors.white, () {
                  _pickAndUploadImage();
                  Navigator.pop(context);
                }),
                _actionButton(Icons.open_with, "move & resize", Colors.white, () {
                  _editProfilePicture();
                  Navigator.pop(context);
                }),
                _actionButton(Icons.delete, "delete", Colors.white, () {
                  setState(() {
                    _canvasWidgets.removeWhere((widget) => widget.key == ValueKey("profile_picture"));
                    _profileImageUrl = null;
                  });
                  Navigator.pop(context);
                }),
                _closeButton(),
              ],
            ),
          );
        },
      );
    }
  }

// 액션 버튼 위젯
  Widget _actionButton(IconData icon, String label, Color iconColor, VoidCallback onTap) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          icon: Icon(icon, color: iconColor, size: 24),
          onPressed: onTap,
        ),
        Text(label, style: TextStyle(color: Colors.white, fontSize: 12)),
      ],
    );
  }

// 닫기 버튼 (❌)
  Widget _closeButton() {
    return IconButton(
      icon: Icon(Icons.close, color: Colors.white, size: 24),
      onPressed: () {
        Navigator.pop(context);
      },
    );
  }




// 프로필 사진 변경 기능 수정
  void _changeProfilePicture() async {
    if (Platform.isAndroid) { // 안드로이드 갤러리 강제로 열기
      final String? imagePath = await platform.invokeMethod('openGallery');

      if (imagePath != null) {
        File selectedImage = File(imagePath);
        await _saveProfilePicture(selectedImage); // ✅ 저장만 수행
        print("✅ 선택한 사진 저장 완료: $imagePath");
      }
    } else if (Platform.isIOS) {
      final pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80, // 최적화된 이미지
        requestFullMetadata: false,
      );

      if (pickedFile != null) {
        File selectedImage = File(pickedFile.path);
        await _saveProfilePicture(selectedImage); // ✅ 저장만 수행
        print("✅ 선택한 사진 저장 완료: ${pickedFile.path}");
      }
    } else {
      print("❌ 오류 발생: 지원되지 않는 플랫폼");
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              color: _canvasColor,
              image: _canvasPattern == "none"
                  ? null
                  : DecorationImage(
                image: AssetImage("assets/patterns/${_canvasPattern}.png"),
                repeat: ImageRepeat.repeat,
              ),
            ),
          ),

          ..._canvasWidgets, // ✅ 기존 기능 유지

          Positioned(
            bottom: 20,
            right: 20,
            child: FloatingActionButton(
              onPressed: _openWidgetSelection,
              child: Icon(Icons.add),
            ),
          ),
        ],
      ),
    );
  }
}

