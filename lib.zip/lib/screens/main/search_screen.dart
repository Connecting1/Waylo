import 'package:flutter/material.dart';

class SearchScreenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: Text('검색 페이지'),
        ),
      ),
    );
  }
}