import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class Friendspage extends StatefulWidget {
  final String userName;
  final String profileImage;

  const Friendspage({
    Key? key,
    required this.userName,
    required this.profileImage,
    required bool isFollowing,
  }) : super(key: key);

  @override
  State<Friendspage> createState() => _FriendspageState();
}

class _FriendspageState extends State<Friendspage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: Colors.white,
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(40),
            child: AppBar(
              automaticallyImplyLeading: true,
              backgroundColor: Colors.white,
              elevation: 0,
              centerTitle: true,
              title: Text(
                widget.userName,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          body: Column(
            children: [
              // 📌 프로필 정보
              Container(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    // 프로필 이미지
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.black, width: 1),
                      ),
                      child: CircleAvatar(
                        radius: 30,
                        backgroundImage: AssetImage(widget.profileImage),
                      ),
                    ),
                    const SizedBox(width: 10),

                    // 사용자 정보 (이름, 상태)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.userName,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text(
                          "이 친구의 프로필",
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                    const Spacer(),

                    // 📌 팔로워/팔로잉 위치 조정 (우측 정렬)
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            print("${widget.userName}의 팔로워 목록 보기");
                          },
                          child: const Text(
                            '팔로워 0',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        const SizedBox(width: 30),
                        GestureDetector(
                          onTap: () {
                            print("${widget.userName}의 팔로잉 목록 보기");
                          },
                          child: const Text(
                            '팔로잉 0',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const Divider(height: 7),

              // 📌 탭바 (게시글 보관함 / 좋아요 보관함)
              SizedBox(
                height: 40,
                child: TabBar(
                  controller: _tabController,
                  indicatorColor: Colors.blue,
                  labelColor: Colors.black,
                  unselectedLabelColor: Colors.grey,
                  labelPadding: const EdgeInsets.symmetric(horizontal: 20),
                  tabs: const [
                    Tab(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.bookmark, size: 18),
                          SizedBox(width: 5),
                          Text("게시글"),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.star, size: 18),
                          SizedBox(width: 5),
                          Text("찜 게시글"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // 📌 탭바 뷰
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildPostArchive(),
                    _buildLikeArchive(),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// 📌 게시글 보관함 (더미 데이터)
  Widget _buildPostArchive() {
    return Center(
      child: Text(
        "${widget.userName}의 게시글 보관함",
        style: const TextStyle(fontSize: 16, color: Colors.grey),
      ),
    );
  }

  /// 📌 좋아요 보관함 (더미 데이터)
  Widget _buildLikeArchive() {
    return Center(
      child: Text(
        "${widget.userName}가 좋아요한 게시물",
        style: const TextStyle(fontSize: 16, color: Colors.grey),
      ),
    );
  }
}
