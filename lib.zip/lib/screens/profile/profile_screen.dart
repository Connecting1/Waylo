import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:waylo_flutter/screens/profile/followers.dart';
import 'package:waylo_flutter/services/api_service.dart';
import '../../styles/app_styles.dart';



class ProfileScreenPage extends StatefulWidget {
  const ProfileScreenPage({Key? key}) : super(key: key);

  @override
  State<ProfileScreenPage> createState() => _ProfileScreenPageState();
}

class _ProfileScreenPageState extends State<ProfileScreenPage> with TickerProviderStateMixin {
  late TabController tabController; //게시물, 좋아요 Tab
  String userName = "Loading...";
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  //네이티브 코드 호출을 위한 채널 설정
  static const platform = MethodChannel('gallery_channel');


  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    loadUserName();
  }

  Future<void> loadUserName() async {
      String fetchedUserName = await ApiService.fetchUserName();  // API 호출
      setState(() {
        userName = fetchedUserName;
      });
    }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {//프로필 이미지 변경
    if(Platform.isAndroid) { // 안드로이드 갤러리 강제로 열기
      //   WidgetsBinding.instance.addPostFrameCallback((_) async {
      //     final String? imagePath = await platform.invokeMethod('openGallery');

      //     if(imagePath != null) {
      //     if(mounted) {
      //       setState(() {
      //         _profileImage = File(imagePath);
      //       });
      //     }
      //   }
      // });
      final String? imagePath = await platform.invokeMethod('openGallery');

      if(imagePath != null) {
        if(mounted) {
          setState(() {
            _profileImage = File(imagePath);
          });
        }
      }
    } else if(Platform.isIOS) {
      final pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80, // 최적화 이미지
        requestFullMetadata: false,
      );
      if(pickedFile != null) {
        setState(() {
          _profileImage = File(pickedFile.path);
        });
      }
    } else {
      print("❌ 오류 ❌");
    }
  }

  void _changeUserName() {
    TextEditingController _controller = TextEditingController(text: userName);
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("이름 변경"),
          content: TextField(
            controller: _controller,
            decoration: const InputDecoration(hintText: "새로운 이름 입력"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text("취소"),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  userName = _controller.text;
                });
                Navigator.pop(context);
              },
              child: const Text("확인"),
            ),
          ],
        );
      },
    );
  }

  //게시글 보관함 / 좋아요 보관함
  Widget _tabMenu() {
    return SizedBox(
      height: 45,
      child: TabBar(
        controller: tabController,
        indicatorColor: AppColors.primary,
        indicatorWeight: 1,
        unselectedLabelColor: Colors.grey,
        labelColor: AppColors.primary,
        labelPadding: const EdgeInsets.symmetric(horizontal:  20),
        tabs: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.bookmark, //게시글 보관함
                    color: Colors.black, size: 18),
                SizedBox(width: 10,),
                Text("게시글 보관함",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),)
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.thumb_up, //좋아요 보관함함
                    color: Colors.black, size: 18),
                SizedBox(width: 10,),
                Text("좋아요 보관함",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabView() {
    return GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: 100,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 1,
          mainAxisSpacing: 1,
          crossAxisSpacing: 1,
        ),
        itemBuilder: (BuildContext context, int index) {
          return Container(
            color: Colors.grey,
          );
        }
    );
  }

  //유저 프로필 정보
  Widget _information() {
    return Column(
      children: [
        //프로필 및 계정 정보
        Container(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              //프로필 이미지(원형/테두리)
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.black, width: 1),
                  ),
                  child: CircleAvatar(
                      radius: 30,
                      backgroundImage: _profileImage != null
                          ? FileImage(_profileImage!) as ImageProvider
                          : const AssetImage('assets/images/nasum.png')
                  ),
                ),
              ),
              const SizedBox(width: 10,),

              //이름, 편집, 아이콘, 계정 관리/로그아웃 텍스트
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        userName,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(width: 8,),
                      GestureDetector(
                          onTap: _changeUserName,
                          child: const Icon(Icons.edit, size: 16)
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(width: 30,),
              const Spacer(),
              //팔로워, 팔로잉 정보
              Row(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FollowersPage(
                              name: userName, selectedTab: 0),
                        ),
                      );
                    },
                    child: const Text(
                      'Follower 0',
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                  ),
                  SizedBox(width: 30,),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FollowersPage(
                              name: userName, selectedTab: 1),
                        ),
                      );
                    },
                    child: const Text(
                      'Following 0',
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const Divider(height: 1, thickness: 0.5),
      ],
    );
  }

  //APP 설정(appBar, body, bottomtapbar)
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit( //앱 화면 비율에 따른 자동 조정(반응형)
      designSize: const Size(360, 690), // 기본 기준 해상도 설정 (Figma 디자인 기준)
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              backgroundColor: Colors.white,
              leading: IconButton(
                icon: const Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              title: const Text(
                "My Page",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              centerTitle: true,
              toolbarHeight: 56, // 기본 AppBar 높이
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  _information(),
                  const SizedBox(height: 5,),
                  _tabMenu(),
                  _tabView(),
                ],
              ),
            )
        );
      },
    );
  }
}