import 'package:flutter/material.dart';
import 'package:waylo_flutter/screens/profile/friendspage.dart';

class FollowersPage extends StatefulWidget {
  final String name; // 사용자 이름
  final int selectedTab; // 선택된 탭 인덱스 (0: 팔로워, 1: 팔로잉)

  const FollowersPage({Key? key, required this.name, this.selectedTab = 0})
      : super(key: key);

  @override
  _FollowersPageState createState() => _FollowersPageState();
}

class _FollowersPageState extends State<FollowersPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.index = widget.selectedTab; // 📌 선택된 탭으로 초기화
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.name,
          style: const TextStyle(
              color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40), // 📌 탭 높이 조정
          child: SizedBox(
            height: 40,
            child: TabBar(
              controller: _tabController,
              indicatorColor: Colors.blue,
              labelColor: Colors.black,
              unselectedLabelColor: Colors.grey,
              labelPadding: const EdgeInsets.symmetric(horizontal: 20),
              tabs: const [
                Tab(text: "팔로워"),
                Tab(text: "팔로잉"),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // 🔍 검색창
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: "검색",
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),

          // 📌 탭바 뷰
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildFollowerList(), // 팔로워 목록
                _buildFollowingList(), // 팔로잉 목록
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// 📌 팔로워 리스트
  Widget _buildFollowerList() {
    final List<Map<String, String>> followersList = [
      {"name": "고은준", "profile": "assets/images/user1.png"},
      {"name": "기가자니", "profile": "assets/images/user2.png"},
    ];

    return ListView.builder(
      itemCount: followersList.length,
      itemBuilder: (context, index) {
        final follower = followersList[index];
        return _buildUserTile(follower["name"]!, follower["profile"]!, true);
      },
    );
  }

  /// 📌 팔로잉 리스트
  Widget _buildFollowingList() {
    final List<Map<String, String>> followingList = [
      {"name": "조지훈", "profile": "assets/images/user6.png"},
    ];

    return ListView.builder(
      itemCount: followingList.length,
      itemBuilder: (context, index) {
        final following = followingList[index];
        return _buildUserTile(following["name"]!, following["profile"]!, false);
      },
    );
  }

  /// 📌 사용자 리스트 타일 (팔로워 & 팔로잉 공통)
  Widget _buildUserTile(String userName, String profileImage, bool isFollower) {
    return ListTile(
      leading: CircleAvatar(
        radius: 25,
        backgroundImage: AssetImage(profileImage), // 프로필 이미지
      ),
      title: Text(
        userName,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Friendspage(
              userName: userName,
              profileImage: profileImage,
              isFollowing: !isFollower, // 팔로워일 경우, 현재 사용자가 팔로우 안 한 상태
            ),
          ),
        );
      },
      trailing: ElevatedButton(
        onPressed: () {
          print("$userName ${isFollower ? "팔로우" : "언팔로우"} 클릭됨");
        },
        style: ElevatedButton.styleFrom(
          backgroundColor:
          isFollower ? Colors.blue : Colors.grey, // 팔로워: 파란색 / 팔로잉: 회색
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: Text(
          isFollower ? "팔로우" : "언팔로우",
          style: const TextStyle(color: Colors.white, fontSize: 14),
        ),
      ),
    );
  }
}
